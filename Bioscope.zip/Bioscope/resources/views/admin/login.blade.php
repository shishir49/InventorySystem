@extends('layout.login')

@section('admin_content')

@include('admin_login')

@endsection

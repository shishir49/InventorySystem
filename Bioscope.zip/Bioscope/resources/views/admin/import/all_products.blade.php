<!-- EDIT / UPDATE /DELETE / VIEW-->

<div class="admin_sidebar">
    <p class="d_title">Dashboard</p>

    <div class="admin_menu_items">
    	<a href="">General</a>
        <a href="">Categories</a>
        <a href="">Products</a>
        <a href="">Sliders</a>
        <a href="">All Orders</a>
    </div> 	

</div>
<div class="dashboard_action">
    <div class="dashboard_title">
        <p>Add Products</p>
    </div> 	

    <div class="dashboard_table">
        <table id="customers">
        	<tr>
        		<th>Category Name</th>
        		<th>Category Image</th>
        	</tr>
        	<tr>
        		<td>Shampoo</td>
        		<td>Image</td>
        	</tr>
        </table>
    </div> 	
</div>	
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <h1>Hello Laravel</h1>
</body>
</html><?php /**PATH E:\laravel3\Bioscope\resources\views/another_section.blade.php ENDPATH**/ ?>
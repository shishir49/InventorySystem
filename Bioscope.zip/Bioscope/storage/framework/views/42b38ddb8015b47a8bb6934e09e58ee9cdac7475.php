

<?php $__env->startSection('admin_content'); ?>

<div class="editproduct">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <?php echo $__env->make('layout.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>
	<div class="dashboard_action">
	    <div class="dashboard_title">
	        <p>Edit Supply Info</p>
	    </div> 	
        <p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_table">

	    	<form method="POST" action="../update-supplier/<?php echo e($get_supplier->id); ?>" enctype="multipart/form-data">

	        <?php echo csrf_field(); ?>
	    		<div class="form-group">
	    			<label>Supplier's Name</label>
	    		    <input type="text" name="supplier_name" value="<?php echo e($get_supplier->supplier_name); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Supplier's Phone Number</label>
	    		    <input type="text" name="phone" value="<?php echo e($get_supplier->phone); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Supplier's Email</label>
	    		    <input type="text" name="email" value="<?php echo e($get_supplier->email); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Mailing Address</label>
	    		    <input type="text" name="mailing_address" value="<?php echo e($get_supplier->mailing_address); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Permanent Address</label>
	    		    <input type="text" name="permanent_address" value="<?php echo e($get_supplier->permanent_address); ?>" class="form-control">
	    		</div>

	    		<div class="form-group">
	    		    <input type="submit" name="submit" class="btn btn-success" value="EDIT">
	    		</div>
	    	</form>
	    </div> 	
	</div>	
</div>

<script>
	$(document).ready(function() {
	    $('#summernote').summernote();
	});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/import/supplies/edit_supplier.blade.php ENDPATH**/ ?>
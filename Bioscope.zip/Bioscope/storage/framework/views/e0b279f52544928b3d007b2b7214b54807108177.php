<div class="site_header">
   <a><div class="logo"><img src="images/logo1.png"/></div></a>

    <div class="navigation_menu">       
        <div class="menu_list">
	           <a href="<?php echo e(route('admin-login')); ?>" class="menu_item ask">Admin Login</a>    
	           <a href="<?php echo e(url('verification')); ?>" class="menu_item">Verify Identity</a>    
		       <a a href="/all-products" class="menu_item">Products</a>     
		       <a href="/" class="menu_item">Home</a>
        </div>  	
    </div>
</div>    <?php /**PATH E:\laravel3\Bioscope\resources\views/layout/header.blade.php ENDPATH**/ ?>
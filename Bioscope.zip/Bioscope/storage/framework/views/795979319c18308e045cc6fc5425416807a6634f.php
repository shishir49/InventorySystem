<div class="admin_menu_items">
      <a href="<?php echo e(route('categories')); ?>">Categories</a>
      <a href="<?php echo e(route('add-category')); ?>">Add Category</a>
      <a href="<?php echo e(route('products')); ?>">Products</a>
      <a href="<?php echo e(route('add-product')); ?>">Add Product</a>
      <!-- <a href="">Import</a> -->
      <a href="<?php echo e(route('suppliers')); ?>">Suppliers</a>
      <a href="<?php echo e(route('add-supplier')); ?>">Add Supplier</a>
      <a href="<?php echo e(route('supplies')); ?>">Supplies</a>
      <a href="<?php echo e(route('add-supply')); ?>">Add supply</a>
      <a href="<?php echo e(route('verification')); ?>">Verification</a>
</div> <?php /**PATH E:\laravel3\Bioscope\resources\views/layout/side_bar.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="">
    <h3><?php echo e($d->product_name); ?></h3>
    <p><?php echo e($d->product_price); ?></p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php echo $data->links(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/testAjaxAction.blade.php ENDPATH**/ ?>
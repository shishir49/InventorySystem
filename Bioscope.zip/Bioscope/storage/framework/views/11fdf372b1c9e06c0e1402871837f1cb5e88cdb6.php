

<?php $__env->startSection('admin_content'); ?>

<div class="addproduct">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <div class="admin_menu_items">
	    	<a href="">General</a>
	        <a href="<?php echo e('categories'); ?>">Categories</a>
	        <a href="<?php echo e('products'); ?>">Products</a>
	        <a href="<?php echo e('add-product'); ?>">Add Product</a>
	        <a href="">Import</a>
	        <a href="<?php echo e('suppliers'); ?>">Suppliers</a>
	        <a href="">Add Supplier</a>
	        <a href="<?php echo e('supplies'); ?>">Supplies</a>
	        <a href="<?php echo e('add-supply'); ?>" style="background: #91a779;">Add supply</a>
	        <a href="<?php echo e('sell'); ?>">Sell</a>
            <a href="">Sliders</a>
	        <a href="">All Orders</a>
	    </div> 	

	</div>
	<div class="dashboard_action">
	    <div class="dashboard_title">
	        <p>Add Supply</p>
	    </div> 	

	    <div class="dashboard_table">

	    	<form method="POST" action="../admin/submit-product" enctype="multipart/form-data">

	        <?php echo csrf_field(); ?>
	        		
	    		<div class="form-group">
	    			<label>Supplier Name</label>
	    			<select class="form-control" name="supplier_name">
	    				<option>Supplier A</option>
	    				<option>Supplier B</option>
	    			</select>
	    		</div>
	    		<div class="form-group">
	    			<label>Supplier's Contact Info</label>
	    		    <input type="text" name="supplier_name" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Supplier's Address</label>
	    		    <input type="text" name="supplier_name" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<h4>Supplied Poducts</h4>
	    			<table width="100%" id="suplly">
	    				<tr>
	    					<th>Item Name</th>
	    					<th>Rate</th>
	    					<th>Item Quantity</th>
	    					<th>Amount</th>
	    					<th style="width:10%"><button type="button" id="add_row" class="btn btn-default"><i class="fa fa-plus"></i></button></th>
	    				</tr>
	    				<tr>
	    					<td><input type="text" name="" value="" class="form-control"></td>
	    					<td><input type="text" name="" value="" class="form-control"></td>
	    					<td><input type="text" name="" value="" class="form-control"></td>
	    					<td><input type="text" name="" value="" class="form-control"></td>
	    					<td><button type="button" class="btn btn-default" onclick=""><i class="fa fa-close"></i></button></td>
	    				</tr>
	    			</table>
	    			
	    			
	    		</div>
	    		<div class="form-group">
	    			<label>Gross Amount</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>

	    		<div class="form-group">
	    			<label>Paying Amount</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>

	    		<div class="form-group">
	    			<label>Due</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>

	    		<h4>Payment Options</h4>

	    		<div class="form-group">
	    			<label>Choose Your Payment Method</label>
	    			<select class="form-control">
	    				<option>Paypal</option>
	    				<option>Visa</option>
	    				<option>Master Card</option>
	    				<option>Cash On Delivery</option>
	    			</select>
	    		</div>

	    		<div class="form-group">
	    			<label>Card Name</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>

	    		<div class="form-group">
	    			<label>Card Number</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>

	    		<div class="form-group">
	    			<label>Expire Date</label>
	    		    <input type="text" name="product_price" class="form-control">
	    		</div>
	    		
	    		<div class="form-group">
	    		    <input type="submit" name="submit" class="btn btn-primary" value="Save">
	    		    <input type="submit" name="submit" class="btn btn-success" value="Make Payment">
	    		</div>
	    	</form>
	    </div> 	
	</div>	
</div>

<script>
	$(document).ready(function() {
	    $('#summernote').summernote();
	});
</script>


<script type="text/javascript">
	$(document).ready(function() {
       $("#add_row").unbind('click').bind('click', function() {
      var table = $("#suplly");
      var count_table_tbody_tr = $("#suplly tr").length;
      var row_id = count_table_tbody_tr + 1;

      $.ajax({
          url: base_url + '/orders/getTableProductRow/',
          type: 'post',
          dataType: 'json',
          success:function(response) {
            

              // console.log(reponse.x);
               var html = '<tr id="row_'+row_id+'">'+
                   '<td>'+ 
                    '<select class="form-control select_group product" data-row-id="'+row_id+'" id="product_'+row_id+'" name="product[]" style="width:100%;" onchange="getProductData('+row_id+')">'+
                        '<option value=""></option>';
                        $.each(response, function(index, value) {
                          html += '<option value="'+value.id+'">'+value.name+'</option>';             
                        });
                        
                      html += '</select>'+
                    '</td>'+ 
                    '<td><input type="number" name="qty[]" id="qty_'+row_id+'" class="form-control" onkeyup="getTotal('+row_id+')"></td>'+
                    '<td><input type="text" name="rate[]" id="rate_'+row_id+'" class="form-control" disabled><input type="hidden" name="rate_value[]" id="rate_value_'+row_id+'" class="form-control"></td>'+
                    '<td><input type="text" name="amount[]" id="amount_'+row_id+'" class="form-control" disabled><input type="hidden" name="amount_value[]" id="amount_value_'+row_id+'" class="form-control"></td>'+
                    '<td><button type="button" class="btn btn-default" onclick="removeRow(\''+row_id+'\')"><i class="fa fa-close"></i></button></td>'+
                    '</tr>';

                if(count_table_tbody_tr >= 1) {
                $("#suplly tr:last").after(html);  
              }
              else {
                $("#suplly").html(html);
              }

              $(".product").select2();

          }
        });

      return false;
    });
	});	
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/suppliers/add_supply.blade.php ENDPATH**/ ?>
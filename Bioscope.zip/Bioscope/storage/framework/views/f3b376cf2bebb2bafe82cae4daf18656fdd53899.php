

<?php $__env->startSection('admin_content'); ?>

<div class="categories">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <?php echo $__env->make('layout.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	

	</div>
	<div class="dashboard_action">
		<p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_title">
	        <p>Categories</p>
	    </div> 	

	    <div class="dashboard_table">
	    	<div class="filter" style="padding:1%;border:1px solid gray;margin-bottom: 1%;background: #e2e6e6;">
	    		<table width="100%">
		    		<form action="/admin/categories" method="GET">
		    			<?php echo csrf_field(); ?>
		    			<tr>
			    			<td><input type="text" class="form-control" name="category_name" placeholder="Category Name"></td>
				    		<td><input type="submit" class="btn btn-success btn-md" name="search" id="btnSearch" value="Search"></td>
		    		    </tr>
		    		</form>
	    	    </table>
	    	</div>
	        <table id="customers">
	        	<tr>
	        		<th>ID</th>
	        		<th>Category Name</th>
	        		<th>Category Image</th>
	        		<th>Action</th>
	        	</tr>
	        	<?php if(count($cats)<1): ?>
					<tr>
						<td colspan="5">No Product Found</td>
					</tr>
				<?php else: ?>	
		        	<?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        	<tr>
	        		<td><?php echo e($loop->iteration); ?></td>
	        		<td><img src="../uploads/<?php echo e($cat->image); ?>" style="width:60px;" alt="no image found" /></td>
	        		<td><?php echo e($cat->category_name); ?></td>
	        		<td>
	        			<a class="edit" href="edit-category/<?php echo e($cat->id); ?>">Edit</a>
			        	<a class="delete" href="cat-delete/<?php echo e($cat->id); ?>">Delete</a>
	        		</td>
	        	</tr>
	        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
	        </table>
	    </div> 	
	</div>	
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    {{-- <h1 style="color:red">{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p> 
    <p>{{ $details['from'] }}</p>  --}}
   
    <p>Thank you</p>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <div class="reset">
   	   <div class="page_title">
   	   	   <h3>Reset Password</h3>
   	   </div>
   	   <div class="resetpanel">
   	   	   <div class="panel_title">
   	   	   	   <h5>In order to Reset your Password, Please provide us the email address regarding your account</h5>
   	   	   </div>
   	   	   <div class="reset_panel_content">
	   	   	   	<form method="POST" action="">
	   	   	   	    <div class="form-group">
	   	   	   	    	<label>Your Email Address</label>
	   	   	   	    	<input type="email" name="" class="form-control">
	   	   	   	    </div>
	   	   	   	    <div class="form-group">
	   	   	   	    	<input type="submit" name="" class="btn btn-success">
	   	   	   	    </div>
	   	   	    </form>
   	   	   </div>
   	   </div>
   </div>
</body>
</html><?php /**PATH E:\laravel3\Bioscope\resources\views/reset-password/reset.blade.php ENDPATH**/ ?>
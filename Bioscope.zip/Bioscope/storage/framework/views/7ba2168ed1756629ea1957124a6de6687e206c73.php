

<?php $__env->startSection('admin_content'); ?>

<div class="products">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <div class="admin_menu_items">
	    	<a href="">General</a>
	        <a href="<?php echo e('categories'); ?>">Categories</a>
	        <a href="<?php echo e('products'); ?>">Products</a>
	        <a href="<?php echo e('add-product'); ?>">Add Product</a>
	        <a href="">Import</a>
	        <a href="<?php echo e('suppliers'); ?>">Suppliers</a>
	        <a href="">Add Supplier</a>
	        <a href="<?php echo e('suppliers'); ?>" style="background: #91a779;">Supplies</a>
	        <a href="<?php echo e('add-supply'); ?>">Add supply</a>
	        <a href="<?php echo e('sell'); ?>">Sell</a>
            <a href="">Sliders</a>
	        <a href="">All Orders</a>
	    </div> 	

	</div>

	<div class="dashboard_action">
		<p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_title">
	        <p>Suppliers</p>
	    </div> 	

	    <div class="dashboard_table">
	    	<div class="filter" style="padding:1%;border:1px solid gray;margin-bottom: 1%;background: #e2e6e6;">
	    		<table width="100%">
		    		<form action="" method="GET">
		    			<tr>
			    			<td>
			    				<select class="form-control">
			    				    <option>Category</option>
				    			</select>
				    		</td>
			    			<td><input type="text" class="form-control" name="product_name" placeholder="Product Name"></td>
			    			<td></td>
				    		<td>
				    			<select class="form-control">
			    				    <option>From</option>
				    			</select>
				    		</td>
				    		<td>	
				    			<select class="form-control">
			    				    <option>To</option>
				    			</select>
		                       
				    		</td>
				    		<td><input type="submit" class="btn btn-success btn-md" name="" value="Search"></td>
		    		    </tr>
		    		</form>
	    	    </table>
	    	</div>
	        <table id="customers">
	        	<tr>
	        		<th width="5%">ID</th>
	        		<th width="10%">Supplier Name</th>
	        		<th width="15%">Supplier Contact</th>
	        		<th width="10%">Supplied Items with Quantity</th>
	        		<th width="10%">Total purchasing Cost</th>
	        		<th width="10%">Total Paid</th>
	        		<th width="10%">Status</th>
	        		<th width="10%">Date</th>
	        		<th width="20%">Action</th>
	        	</tr>
	        	<?php if(count($prod)<1): ?>
					<tr>
						<td colspan="5">No Product Found</td>
					</tr>
				<?php else: ?>	
		        	<?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						    <td><?php echo e($loop->iteration); ?></td>
			        		<td><?php echo e($product->supplier_name); ?></td>
			        		<td><?php echo e($product->supplier_contact); ?></td>
			        		<td><?php echo e($product->supplied); ?></td>
			        		<td><?php echo e($product->cost); ?></td>
			        		<td><?php echo e($product->paid); ?></td>
			        		<td><?php echo e($product->status); ?></td>
			        		<td><?php echo e($product->created_at); ?></td>
			        		<td>
			        			<a class="edit" href="edit-product/<?php echo e($product->id); ?>">Edit</a>
			        			<a class="delete" href="delete/<?php echo e($product->id); ?>">Delete</a>
			        			<a class="delete" href="delete/<?php echo e($product->id); ?>">Print</a>
			        		</td>
			        	</tr>
		        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
	        </table>

	         <div class="d-flex justify-content-center" style="margin-top: 1%"><?php echo $prod->links(); ?> </div> 
	    </div> 	
	</div>	
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/import/index.blade.php ENDPATH**/ ?>
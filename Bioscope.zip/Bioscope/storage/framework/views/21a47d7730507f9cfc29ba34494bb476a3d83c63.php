

<?php $__env->startSection('admin_content'); ?>

<div class="editproduct">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <div class="admin_menu_items">
	    	<a href="">General</a>
	        <a href="<?php echo e('../categories'); ?>">Categories</a>
	        <a href="<?php echo e('../products'); ?>" style="background: #91a779;">Products</a>
	        <a href="<?php echo e('../add-product'); ?>">Add Product</a>
	        <a href="">Import</a>
	        <a href="<?php echo e('../suppliers'); ?>">Suppliers</a>
	        <a href="">Add Supplier</a>
	        <a href="<?php echo e('../supplies'); ?>">Supplies</a>
	        <a href="<?php echo e('../add-supply'); ?>">Add supply</a>
	        <a href="<?php echo e('../sell'); ?>">Sell</a>
            <a href="">Sliders</a>
	        <a href="">All Orders</a>
	    </div> 	

	</div>
	<div class="dashboard_action">
	    <div class="dashboard_title">
	        <p>Edit Product</p>
	    </div> 	
        <p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_table">

	    	<form method="POST" action="../update-product/<?php echo e($get_product->id); ?>" enctype="multipart/form-data">

	        <?php echo csrf_field(); ?>
	    		<div class="form-group">
	    			<label>Product Name</label>
	    		    <input type="text" name="product_name" value="<?php echo e($get_product->product_name); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Category</label>
	    			<select name="category_id" class="form-control">
	    				<option value="<?php echo e($get_product->category_id); ?>"><?php echo e($get_product->category_id); ?></option>
	    				<?php $__currentLoopData = $get_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    				<option value="<?php echo e($cats->id); ?>"><?php echo e($cats->category_name); ?></option>
	    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    			</select>
	    		</div>
	    		<div class="form-group">
	    			<label>Product Image</label>
	    			<input type="hidden" name="default" value="<?php echo e($get_product->image); ?>" class="form-control">
	    			<div class="im" style="width: 50px">
	    				<img src="../../uploads/<?php echo e($get_product->image); ?>" style="width: 100%;">
	    			</div>
	    		    <input type="file" name="image" placeholder="<?php echo e($get_product->image); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Product Price</label>
	    		    <input type="text" name="product_price" value="<?php echo e($get_product->product_price); ?>" class="form-control">
	    		</div>
	    		<div class="form-group">
	    			<label>Product Description</label>
	    			<textarea id="summernote" name="product_description"><?php echo e($get_product->product_description); ?></textarea>
	    		</div>
	    		<div class="form-group">
	    		    <input type="submit" name="submit" class="btn btn-success" value="EDIT">
	    		</div>
	    	</form>
	    </div> 	
	</div>	
</div>

<script>
	$(document).ready(function() {
	    $('#summernote').summernote();
	});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/products/edit_product.blade.php ENDPATH**/ ?>
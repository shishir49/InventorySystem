<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <?php $__currentLoopData = $get_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($g->product_name); ?></p>
    <p><?php echo e($g->categories->category_name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH E:\laravel3\Bioscope\resources\views/relationship.blade.php ENDPATH**/ ?>
<div class="admin_sidebar">
    <p class="d_title">Dashboard</p>

   <?php echo $__env->make('layout.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

</div>
<div class="dashboard_action">
    <div class="admin_welcome">
       <h1>Welcome Home ! </h1>
    </div>  

    <div class="admin_info">
        <div class="admin_panel_info_card">
            <h3>Total Categories : <?php echo e(count($c)); ?></h3>
        </div>

        <div class="admin_panel_info_card">
            <h3>Total Products : <?php echo e(count($p)); ?></h3>
        </div>

        <div class="admin_panel_info_card">
            <h3>Total Import: <?php echo e(count($s)); ?></h3>
        </div>

        
    </div>
      
</div>  


   <?php /**PATH E:\laravel3\Bioscope\resources\views/admin_welcome.blade.php ENDPATH**/ ?>
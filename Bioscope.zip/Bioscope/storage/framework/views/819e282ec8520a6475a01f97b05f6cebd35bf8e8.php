<div class="admin_header">
   <div class="user_nav">
   	   
   	   <div class="logout" style="padding:10%;">
   	    <p class=""><a href="<?php echo e(route('logout')); ?>" style="color:white;text-decoration: none;">Logout</a></p>
       </div>
   </div>
   
</div>	<?php /**PATH E:\laravel3\Bioscope\resources\views/layout/admin_header.blade.php ENDPATH**/ ?>
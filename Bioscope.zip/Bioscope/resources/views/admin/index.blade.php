@extends('layout.admin_layout')

@section('admin_content')

@include('admin_welcome')

@endsection

@extends('layout.master')

@section('content')

@include('slider')

@endsection

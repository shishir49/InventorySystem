@extends('layout.master')

@section('content')

@include('reset-password.reset')

@endsection



<?php $__env->startSection('admin_content'); ?>

<div class="products">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <?php echo $__env->make('layout.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	

	</div>

	<div class="dashboard_action">
		<p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_title">
	        <p>Supplies</p>
	    </div> 	

	    <div class="dashboard_table">
	    	<div class="filter" style="padding:1%;border:1px solid gray;margin-bottom: 1%;background: #e2e6e6;">
	    		<table width="100%">
		    		<form action="" method="GET">
		    			<?php echo csrf_field(); ?>
		    			<tr>
			    			<td><input type="text" class="form-control" name="supplier_name" placeholder="Supplier Id">
			    			</td>
			    			
				    		<td><input type="submit" class="btn btn-success btn-md" name="" value="Search"></td>
		    		    </tr>
		    		</form>
	    	    </table>
	    	</div>
	        <table id="customers">
	        	<tr>
	        		<th width="5%">ID</th>
	        		<th width="10%">Supplier Name</th>
	        		<th width="10%">Item Name</th>
	        		<th width="10%">Rate</th>
	        		<th width="10%">Quantity</th>
	        		<th width="10%">Total Cost</th>
	        		<th width="10%">Paid</th>
	        		<th width="10%">Status</th>
	        		<th width="10%">Date</th>
	        		<th width="5%">Action</th>
	        	</tr>
	        	<?php if(count($supplies)<1): ?>
					<tr>
						<td colspan="5">No Product Found</td>
					</tr>
				<?php else: ?>	
		        	<?php $__currentLoopData = $supplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						    <td>#<?php echo e($supply->supplier_id); ?></td>
			        		<td><?php echo e($supply->suppliers->supplier_name); ?></td>
			        		<td><?php echo e($supply->item_details); ?></td>
			        		<td><?php echo e($supply->rate); ?></td>
			        		<td><?php echo e($supply->quantity); ?></td>
			        		<td><?php echo e($supply->total_cost); ?></td>
			        		<td><?php echo e($supply->paying); ?></td>
			        		<td>
			        			<?php if($supply->due ==0): ?>
			        			   <button class="btn btn-success btn-sm">paid</button> 
			        			<?php else: ?>
			        			   <p style="color: red">Due <?php echo e($supply->due); ?></p> 
			        			<?php endif; ?>   
			        		</td>
			        		<td><?php echo e($supply->created_at); ?></td>
			        		<td>
			        			<a class="edit" href="update-supply/<?php echo e($supply->id); ?>">Edit</a>
			        			<a class="delete" href="sdelete/<?php echo e($supply->id); ?>">Delete</a>
			        			
			        		</td>
			        	</tr>
		        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
	        </table>

	         <div class="d-flex justify-content-center" style="margin-top: 1%"><?php echo $supplies->links(); ?> </div> 
	    </div> 	
	</div>	
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/import/supplies/index.blade.php ENDPATH**/ ?>
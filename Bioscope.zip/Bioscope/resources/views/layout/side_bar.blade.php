<div class="admin_menu_items">
      <a href="{{route('categories')}}">Categories</a>
      <a href="{{route('add-category')}}">Add Category</a>
      <a href="{{route('products')}}">Products</a>
      <a href="{{route('add-product')}}">Add Product</a>
      <!-- <a href="">Import</a> -->
      <a href="{{route('suppliers')}}">Suppliers</a>
      <a href="{{route('add-supplier')}}">Add Supplier</a>
      <a href="{{route('supplies')}}">Supplies</a>
      <a href="{{route('add-supply')}}">Add supply</a>
      <a href="{{route('verification')}}">Verification</a>
</div> 
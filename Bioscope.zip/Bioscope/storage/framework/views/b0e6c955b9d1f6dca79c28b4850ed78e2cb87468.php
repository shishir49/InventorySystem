<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    
   
    <p>Thank you</p>
</body>
</html><?php /**PATH E:\laravel3\Bioscope\resources\views/emails/myTestMail.blade.php ENDPATH**/ ?>
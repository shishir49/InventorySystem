<div>
        <div class="site_footer">
            <div class="footer_column">
                <div class="site_logo">
                    <a><div class="footer_logo"><img src="http://127.0.0.1:8000/images/logo1.png"/></div></a>
                   
                </div>    
                <div class="footer_address">
                    <p><i class="fas fa-map-marker-alt"></i> &nbsp; House- 8, Road- 9/A, Sector- 05</p>
                    <p>Uttara Model Town</p>
                    <p>Dhaka- 1230</p>
                    <p>Bangladesh.</p>
                    <p><i class="fas fa-phone"></i>&nbsp;  +88 02 8916319</p>
                    <p><i class="fas fa-mobile-alt"></i> &nbsp; +88 01711856660, +8801777255555</p>
                    <p><i class="fas fa-envelope"></i> &nbsp; helloyoubd@gmail.com</p>
                </div>    
            </div>    
            <div class="footer_column">
                 <div class="footer_title">
                     <h2>Products</h2>
                 </div>    
                 <div class="footer_content">
                    <a class="footer_item">Dental Care Builder</a>
                    <a class="footer_item">Healthcare</a>
                    <a class="footer_item">Hello You BD. Com</a>
                    <a class="footer_item">Orthopedic Rehabilitions</a>
                    <a class="footer_item">Skin Care</a>
                    <a class="footer_item">Surgical Equipments</a>
                 </div>    
            </div> 
            <div class="footer_column">
                 <div class="footer_title">
                     <h2>Company</h2>
                 </div>    
                 <div class="footer_content">
                    <a class="footer_item">About Us</a>
                    <a class="footer_item">Our Network</a>
                 </div> 
                 <div class="footer_title">
                     <h2>Social</h2>
                 </div>    
                 <div class="footer_content">
                    <a class="footer_social"><i class="fab fa-facebook"></i></a>
                    <a class="footer_social"><i class="fab fa-twitter"></i></a>
                    <a class="footer_social"><i class="fab fa-youtube"></i></a>
                 </div> 
            </div> 
            <div class="footer_column">
                <div class="map">
                     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3648.5339836895196!2d90.39633761429937!3d23.870676490089348!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c43b58d55871%3A0x89efd875ac760d93!2s8%20Road-9%2FA%2C%20Dhaka%201230!5e0!3m2!1sen!2sbd!4v1609005222273!5m2!1sen!2sbd" width="100%" height="200" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>    
            </div> 
        </div>   
        <div class="copyright">
                <p>Copyright © 2014 All Rights reserved by Bio-Scope Inc. Design and Developed by: Uttara InfoTech</p>
        </div> 
</div> <?php /**PATH E:\laravel3\Bioscope\resources\views/layout/footer.blade.php ENDPATH**/ ?>


<?php $__env->startSection('admin_content'); ?>

<div class="products">
    <!-- EDIT / UPDATE /DELETE / VIEW-->

	<div class="admin_sidebar">
	    <p class="d_title">Dashboard</p>

	    <?php echo $__env->make('layout.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	

	</div>

	<div class="dashboard_action">
		<p style="text-align: center;"><?php echo e(session('msg')); ?></p>
	    <div class="dashboard_title">
	        <p>Suppliers</p>
	    </div> 	

	    <div class="dashboard_table">
	    	
	    	<div class="filter" style="padding:1%;border:1px solid gray;margin-bottom: 1%;background: #e2e6e6;">
	    		<table width="100%">
		    		<form action="/admin/import/suppliers" method="GET">
		    			<?php echo csrf_field(); ?>
		    			<tr>
			    			<td><input type="text" class="form-control" name="supplier_name" placeholder="Supplier Name"></td>
				    		<td><input type="submit" class="btn btn-success btn-md" name="search" id="btnSearch" value="Search"></td>
		    		    </tr>
		    		</form>
	    	    </table>
	    	</div>
	        <table id="customers">
	        	<tr>
	        		<th width="5%">ID</th>
	        		<th width="15%">Supplier's Name</th>
	        		<th width="10%">Supplier's Phone/Mobile</th>
	        		<th width="10%">Supplied's Email</th>
	        		<th width="20%">Mailing Address</th>
	        		<th width="20%">Permanent Address</th>
	        		<th width="20%">Action</th>
	        	</tr>
	        	<?php if(count($sup)<1): ?>
					<tr>
						<td colspan="5">No Product Found</td>
					</tr>
				<?php else: ?>	
		        	<?php $__currentLoopData = $sup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						    <td><?php echo e($loop->iteration); ?></td>
			        		<td><?php echo e($sp->supplier_name); ?></td>
			        		<td><?php echo e($sp->phone); ?></td>
			        		<td><?php echo e($sp->email); ?></td>
			        		<td><?php echo e($sp->mailing_address); ?></td>
			        		<td><?php echo e($sp->permanent_address); ?></td>
			        		<td>
			        			<a class="edit" href="edit-supplier/<?php echo e($sp->id); ?>">Edit</a>
			        			<a class="delete" href="delete-supplier/<?php echo e($sp->id); ?>">Delete</a>
			        		</td>
			        	</tr>
		        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
	        </table>

	         <div class="d-flex justify-content-center" style="margin-top: 1%"><?php echo $sup->links(); ?> </div> 
	    </div> 	
	</div>	
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\Bioscope\resources\views/admin/import/suppliers/index.blade.php ENDPATH**/ ?>